package com.example.fmc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
